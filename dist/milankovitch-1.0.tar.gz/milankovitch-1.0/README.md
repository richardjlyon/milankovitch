# Milankovitch

**A python script for examining Milankovitch cycle components in the Earth's global sea level record.**

![output](milankovitch/milankovitch.png)

Global sea level has varied by over 120 meters in the last 500,000 thousands years. Examination of the data reveals
at least one cyclical component at a period of around 100,000 years.

This script applies the Fourier Transform to sea level data to compute the power spectra. This reveals significant
frequencies corresponding to the Earth's orbital ellipticity, axial tilt, and axial precession.

## Datasources

| Name                                              | Source                                                                                                                     | Description                                                                    |
|:--------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| [edc3deuttemp2007.txt](data/edc3deuttemp2007.txt) | [NOAA](https://www.ncei.noaa.gov/access/paleo-search/study/6080)                                                           | European Project for Ice Coring in Antarctica Dome C ice core temperature data |
| [RSL_data.xlsx](data/RSL_data.xlsx)               | [Research School of Earth Sciences](https://github.com/ANU-RSES-Education/EMSC-4033/tree/master/Notebooks/StepByStep/Ex17) | Sea level data                                                                 |