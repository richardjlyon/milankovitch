from pathlib import Path

ROOT = Path.cwd().parent