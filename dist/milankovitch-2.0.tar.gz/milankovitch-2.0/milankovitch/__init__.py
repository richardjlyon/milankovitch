from pathlib import Path

ROOT = Path(__file__).parent.parent
PLOTDIR = ROOT / "plots"
